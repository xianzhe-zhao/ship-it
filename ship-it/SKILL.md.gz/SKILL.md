---
name: ship-it
description: "代码变更→测试→发布（契约模式），9 步不跳步：澄清→spec 签约→编码→测试→核销→验收→PR→发布→清理。签约只认只含“签约”两个字的用户消息，验收只认只含“验收”两个字；核销、审查、开工/暂停闸门与全文一致性由 check_spec/check_roles/check_docs/check_text/guard_large_write 机器校验。团队模式含代码安全员/审查员/裁判员。触发词：改代码、修 bug、加功能、重构、需求评审、安全审查、漏洞、写个 spec、契约、验收标准、写测试、回归测试、E2E、视觉自测、准备 PR、版本号、发布、上线、deploy、release。"
version: 4.7.2
---

# ship-it（开发发布工作流 · 契约模式）

把“用户提需求 → 改完代码 → 发布上线”固化成可核销的 9 步：spec 先落盘，代码与测试从契约派生，验收按条款打勾，发布带回滚。每步有产出物和闸门，不跳步。

## 0. 铁律（违反即停）

1. 用户消息 `strip()` 后严格等于“签约”才编码；严格等于“验收”才进 PR；其他表述都不算。
2. spec 先于实现；spec 正文改动 → 签约失效，回 draft 重签。
3. 执行者 ≠ 裁定者：核销 ✅、角色报告、能力声明必须机器可查或用户确认。
4. 团队模式必派角色必须有独立只读报告；单会话至少 1 名只读 subagent；不得自检替代。
5. 核销 ✅ 必须能追到用例文件、用例名、报告路径；虚构即 FAIL。
6. 测试从契约派生，不从代码派生；SKIP 必须退出码 2。
7. >50KB 文本整体重写先 `guard_large_write.py prepare`，写后 `check`，失败 `restore`。
8. 9 步不跳步；Step 6 用户验收不可省；合并前不碰生产。
9. 任何时候禁止 AI 合并 PR；PR 创建即停。
10. 需求变更先改 spec；不得绕过 spec 打补丁。
11. 凭据不入文档/脚本/commit；报告只写证据。
12. 结论前置、一条一句、禁模糊词、每条规则有判定方式（见 `references/rule-style.md`）。
13. 审查员在第一个写任务前派发并落盘 patrol；`check_roles --stage start` 必须为 0；主脑不得代写或内联替代。
14. 用户改契约先暂停：`status: paused` + pause 记录（先于 spec 编辑）+ 审查员发暂停令；重新签约后才恢复；主脑不得直接给子代理发结束令。
15. 失败先分类：派发失败 1 次换新子智能体；执行失败 3 次换新；主脑不得自做；无收尾消息 = 执行失败；仍失败报用户。
16. 全文一致性：`check_docs.py`、`check_text.py` 退出码 0；旧口径/过期计数/重复/矛盾清零。

## 文件地图

- `references/rule-style.md` 文本铁律与硬禁用词；`references/security-review.md` 周期安全审查 playbook；`references/security-kb.md` 代码安全员审查库。
- `references/spec-template.md` spec 模板（签约/验收块、入口清单、P1..Pn、5 列核销）；`references/self-check.md` 自检与坐标断言；`references/project-adaptation.md` 项目接入；`references/team-mode.md` 团队角色与派发协议。
- `scripts/check_spec.py` spec 四阶段（draft/spec/verify/accept）与 `--git-check`；`scripts/check_roles.py` 闸门（`--stage start|pause|sign|verify|accept`）；`scripts/check_docs.py` 全文一致性；`scripts/check_text.py` 文本质量；`scripts/guard_large_write.py` 大文件写保护；`scripts/pre_commit_check.py` pre-commit（`check` / `install-hooks`，`--base` 默认 `HEAD`）。

## 何时使用 / 系统形态 / 部署通道

用户提出需要**修改代码并最终交付/发布**的需求时启用：修 bug、加功能、重构、改配置、改接口、升级依赖；或用户说“改一下 XX”“修复 XX”“加个 XX 功能”“优化 XX”“这个功能安全吗”。**不适用**：纯问答、只读分析、查日志、诊断但不改代码。

| 形态 | 测试系统 | 正式系统 | Step 4 部署测试 | Step 8 发布正式 |
|---|---|---|---|---|
| 单系统 | 无 | 无 | 本地测试即可 | 跳过 |
| 有测试环境 | 有 | 无 | 部署测试系统 | 跳过 |
| 测试 + 正式 | 有 | 有 | 部署测试系统 | 发布正式系统 |

查项目文档（README/CLAUDE.md/AGENTS.md）是否提到 test/staging/prod、CI/CD、部署脚本；不确定直接问用户。部署通道与形态正交：查 `.github/workflows/`、`.gitlab-ci.yml` 有无分支→环境部署映射；只有测试/构建、没有部署 job 不算自动发布通道。判定为 CI/CD 自动发布 → 把分支→环境→workflow 映射记入 `docs/deploy-runbook.md`；无法判定 → 直接问用户，不得默认。

## 团队模式

用户提需求时判断执行形态：**多文件 / 全栈 / 用户明确要求 → 团队模式**；否则单干（mini-spec 恒单干）。判断与理由写进 spec「方案自审」，用户可否决。

- **角色**：需求澄清员 / 后端开发 / 前端开发 / 代码安全员（代码审查+安全检查，团队模式必执行）/ 审查员（异常与偷懒审查），主脑唯一汇总接口 / 裁判员（测试+审查/安全通过后审契约，不审代码/不测试）/ 测试员（只做验收测试）。主脑是 spec 唯一 owner、用户唯一对接人、唯一对用户交付成员；单写“审查员”指异常与偷懒审查角色；改动说明员已删除，Step 6 五项报告由主脑汇总团队产出后起草。
- **模型派发**：默认路由优先，派发不指定模型；仅硬能力不满足（测试员图像输入，实测为证）或用户显式要求时，查本会话放行集合（DSH：`list_subagent_models`）按硬能力 > 软能力 > 性价比挑选；路由不可用自动回退并注明，不停摆；skill 正文零模型名。
- **监督**：审查员间隔 1 分钟巡视所有成员（含主脑/裁判员/代码安全员/测试员/开发），patrol 落 `docs/reviews/<date>-auditor-patrol.md`（轮次/时间/成员/状态/证据/异常/动作；末轮必须写 `last_active_at`，且 ≥ max(first_write_at, test_run_finished)-5min，C11）；发现 inactive 未完成、主脑 idle 有剩余任务、running 无进展即催办/上报；可直发 `continue`/`retry_same`，换模型/换范围/新派发交主脑；宿主不支持持久定时 → 事件触发巡视（每轮记 trigger）并声明“无主动定时巡视”降级。
- **心跳**：主脑不持续轮询；5 分钟无审查员消息 → 主动询问/唤醒；审查员 5 分钟无主脑确认 → 再次上报/唤醒；审查员汇总每个报告前必须分析并至少反问 1 个问题，主脑可反向质疑，未解决不呈现。
- **写权限**：审查员只读，但可写 `docs/reviews/<date>-` 下 patrol/pause/auditor/failure-log/referee-start/security-start/auditor-start 7 类记录，其他文件不得写；patrol 原文不得篡改。
- **开工闸门**：第一个写任务前必须派发并落盘 patrol（首轮早于首个写任务、轮次 ≥3、间隔 ≤5 分钟或事前声明事件触发）；三份 start artifact（referee/security/auditor）由本人写；`check_roles --stage start` 必须为 0；C6 首写标记 `tmp/first-write.json` 的 `first_write_at` 必须晚于 start/patrol 启动时间；C11 在 start/verify/accept 校验 patrol 末轮 `last_active_at`。
- **契约变更暂停**：用户要求改已签约 spec → 主脑先把 spec 置 `status: paused`；审查员向所有活跃子代理发暂停/结束令（主脑只向审查员下达意图）；暂停前快照当前 spec 到 `tmp/spec-before-<rev>.md`；pause 记录写 `spec_before_revision/hash/snapshot` 且先于任何 spec 编辑落盘；`check_roles --stage pause --spec <spec>` 必须为 0；暂停期间只做只读盘点与 spec 编辑；重新“签约”+新 `sign_hash` 后才恢复。
- **reviewer 派发/汇总（C8/C12）**：主脑在派发/返回/检查点必须唤醒 reviewer；patrol 顶层记录 `reviewer_dispatch`、`reviewer_dispatch_at`、`heartbeat_effective_at`、`role_dispatch`、`last_active_at`、`汇总来源`（五角色路径）；`check_roles` 校验顺序/间隔/覆盖。
- **角色复用（C13）**：默认 `send_message` 唤醒现有角色；新开仅 `new_missing`/`new_overflow`/`new_independent`/`new_replace` 且附 reason；`role_dispatch` 记录 source。
- **不打扰用户（C14）**：签约/验收提醒各一次，之后不重复催促；心跳提醒可能对用户可见（schedule_create reminder 投递到 session），仅在 dev/tester 活跃期启用、间隙暂停；异常或用户询问才主动通知；其余场景被动响应；不重复相同进度。
- **最小独立审查**：单会话至少 1 名只读 subagent 独立出报告；不得以主脑自检替代；派不出 → 声明“无独立审查”，不得自判 PASS；三类角色报告的审查者与会话标识两两不同，referee 的 J1/J3/J4 可同人同会话；报告含 `spec_revision`/`spec_hash`/`汇总来源`；`汇总来源` 必须列子代理报告路径且文件存在（无子代理写“无子代理报告（叶子会话）”，C12）；主脑只接收审查员汇总，直接收/采纳子代理报告 = FAIL，主脑直收记录写 patrol（裁判员判）。
- **按需矩阵**：形态 0 单干 / 1 小改 / 2 中改 / 3 大改高风险；需求澄清员按需，代码安全员/审查员/裁判员/测试员团队模式必须执行（主脑单干例外且自测）；深度安全审计/方案评审/发布验证为可选专项。
- **目标驱动编排（可选）**：签约时问用户是否启用“目标 + 任务树”（主脑不代选）；启用则 `create_goal` + 按 Step 1–9 分组建树（叶子可检查、节点 ≤40）、派发带 `Timeline: tree=…; tasks=…` 标识与完成标准、每步写回进度，Step 5 核销表加「目标树」机器行，Step 6 用户验收后关闭目标。
- **失败分类**：派发失败（未启动：权限/路由/工具缺失）→ 1 次后换新子智能体；执行失败（已启动但超时/报错/空产出/无收尾消息）→ 3 次后换新；主脑不得自做，仍失败报用户；attempt 写入 `docs/reviews/<date>-failure-log.md`；审计角色例外：审查员失败 → 换新审查员，仍失败声明“无独立审查”并阻塞 start；裁判员失败 → 换新 subagent，仍失败报用户，不得自判 PASS。子代理最终消息必须含完整产出物；只回元信息 = 执行失败。

## 周期安全审查（流程外）

- 默认每月一次；对外暴露面大/依赖多的项目可每周一次；周期记入项目 runbook。首次使用/从未审查 → 开工前先做一次完整审查。
- 完整核验：`npm audit` + OSV + 官方公告/GHSA/NVD 原文，判定 P0/P1/P2；playbook 见 `references/security-review.md`。
- 结果日志记入项目 `docs/security-review-log.md`（日期/范围/联网核验状态/P0P1P2 清单/结论），入 git。
- P0 规则：周期审查发现 P0 → 相关功能未清零不开工/不发布；新增依赖命中已知 P0 → 禁用。
- 增量检查（Step 2 前，1 分钟）：距上次审查有无新增依赖/新外部输入面？有 → 只核验增量，结论写进 spec「方案自审」；无 → PR 写一行“自上次审查（YYYY-MM-DD）无新增攻击面”。

## 流程总览

| 阶段 | 步骤 | 产出物 | 闸门 |
|---|---|---|---|
| ① 问清楚 | 1 需求澄清与提示词优化 | 优化后需求 + 澄清记录 | 需求无歧义、技术可行 |
| ② 说清楚 | 2 方案自审 + 技术蓝图 + spec 落盘 | spec（含方案自审/技术蓝图/入口清单） | 三问全过；用户严格“签约”；`check_spec --stage spec` 退出码 0 |
| ③ 写代码 | 3 编码 + 自检 | 构建通过 | `check_roles --stage start` 退出码 0；语法/测试/门禁通过；UI 坐标断言；六项复查；>50KB guard 通过 |
| ④ 可验证 | 4 测试（两支柱）+ 部署测试系统 | 用例（名字带条款号）+ 回归报告 | 核心没修坏；每条 C 有用例；入口逐条跳转；SKIP 退出码 2 |
| ⑤ 机器验收 | 5 契约核销表 | 5 列核销表 + 测试报告 | 条款 100% 核销；check_spec verify / check_roles verify / check_docs / check_text 退出码 0 |
| ⑥ 人工验收 | 6 用户按清单打勾 | 用户确认 | 用户严格“验收”；`check_spec --stage accept` 退出码 0 |
| ⑦ 交付 | 7 版本号 + PR | PR（核销表 + 回滚卡） | `check_roles --stage accept` 退出码 0；PR 创建即停 |
| ⑧ 生产 | 8 合并后发布正式系统 | 回滚预案 + 端到端验证 | 生产健康 200 + 产物可达 |
| ⑨ 收尾 | 9 清理 + 记录 | CHANGELOG/deploy-log | 无测试/垃圾文件残留 |

> 团队监督闸门：代码安全员必执行；审查员按异常/偷懒介入；裁判员 J1 签约前 / J2 编码后 / J3 核销前 / J4 验收前（BLOCK 可阻断下一步；PASS 不替代用户验收与机器校验）。

## Step 1：需求澄清与提示词优化（每次做，分轻重）

- 三种手段按需组合：①联网搜索（官方文档/可行方案）②向用户提问（有歧义点一次性问完）③主脑优化（口语化需求重写为专业、准确、可执行描述）。
- 跨仓库主体确认：需求涉及 ≥2 个仓库/项目时，必须显式确认“规范基准是哪个项目？改动对象是哪个项目？”并写进需求澄清记录。
- 输出：优化后需求 + 需求澄清记录（原始→优化+说明+用户问答）→ spec 第 1 节，签约时展示给用户确认理解对不对。
- 团队模式：**按需**派**需求澄清员** subagent（一次性，不直接面对用户）做联网搜索+分析+问题清单；清晰需求/小改由主脑兼任。需求模糊或跳过需求澄清员 → 主脑组织审查员/裁判员契约互审（至少 1 轮）后再向用户总结最终契约。
- 分轻重：清晰需求快速过；模糊需求（缺关键要素/涉及不熟悉技术/有歧义）深入；用户说“帮我理一下需求” → 深入做。

## Step 2：方案自审 + 技术蓝图 + spec 契约落盘（签约后编码）

### 方案自审（写进 spec「方案自审」节）

1. 现有能力盘点（必须实际查）：逐层查页面/路由、组件、公共逻辑、后端接口、数据表、脚本工具、依赖；目录映射见 `references/project-adaptation.md`。
2. 三选一决策（必须写理由）：A 复用（现有能力直接满足，只改配置/数据/文案）；B 扩展（现有能力约 80% 满足，加参数/字段/分支且向后兼容）；C 新建（确实没有且复用显著增加复杂度，必须写“复用成本 vs 新建成本”对比）。默认 A/B；选 C 不写对比 = 未通过自审。
3. 影响面分析：用 `grep` 查调用方/表/配置，写进 spec：受影响页面/路由、接口与调用方、表/字段（含历史数据）、配置/缓存/端口、回归范围；回答是否引入新状态/并发/权限分支、数据模型是否向前兼容、是否改变接口契约。
4. 入口清单：从实际架构扫描导航/仪表盘/底栏/深链/搜索/快捷入口/API 调用方等入口；每个入口写打开方式与预期。无 UI 变更 → spec §2 写 `入口清单：无 UI 变更`。
5. 成本预算：涉及 LLM/付费 API 写单次/日上限与限流；不涉及写“无”。
6. 测试策略：写 3–5 条可验证验收条件（DoD）→ 升格为 C 条款；指明回归范围；新增 E2E 断言/测试数据只允许写测试库。

### 技术蓝图（写进 spec「技术蓝图」节，不涉及的写“无变更”）

前端：页面/组件改动、UI 坐标断言点、设计规范遵循。后端：接口契约（参数/返回/错误码）、业务逻辑变更。数据库：表/字段变更、向前兼容、迁移脚本。环境依赖：新增依赖/服务/配置/端口/环境变量；依赖变更走审批。

### 落盘 spec 契约

默认路径 `docs/specs/YYYY-MM-DD-<英文短名>.md`，模板见 `references/spec-template.md`（front matter 含签约/验收块、`hash_scope`）。节：1 背景与目标+需求澄清记录（what & why ≤5 行）；2 方案自审+入口清单+流程规则 P1..Pn（P 只用于流程规则）；3 技术蓝图；4 非目标；5 契约条款 C1/C2/…（前置/后置/失败/不变式，🔒 标受保护规则）；6 验收标准 A1/A2/…；7 边界与异常；8 三问完整性检查+DoR。

写条款四条硬标准：①可验证（能写测试用例或明确页面断言）；②一条一句；③不写实现；④失败行为必写（状态码/错误文案/是否泄露内部信息）。受保护规则 🔒 不可被悄悄改；改这些事实必须产生显式 Diff 等用户审批（防“同源共错”）。

### 三问完整性检查（答不出任何一问 = 回去补）

① 每个字段的取值范围能否用正则/枚举/数值区间精确描述？② 有状态的流程能否画成状态机（含触发条件与 guard）？③ 每个输出的生成逻辑能否用一句话（函数调用）描述？DoR 自检：需求无歧义、技术可行、影响面已盘。

### 签约与 spec-first

- spec 入 git；**spec 首次提交必须 docs-only**（只含 docs：spec + 审查报告，且该提交里的 spec 已含 `status: signed`、`sign_quote: 签约` 与正确 `sign_hash`）；**实现文件**含 `docs/` 下非 spec/reviews、`ship-it/**/*.md`、README、模板、team-mode、scripts/tests——`.md` 不是天然豁免；实现首次提交不得早于最新 signed spec 的 docs-only 提交。
- `hash_scope`：每个 spec front matter 必须写 `full_body` / `sections_1_8` / `sections_1_8_a_normalized`；`--git-check` 按每个提交内 spec 的 `hash_scope` 计算；缺省按日期/修订推断（旧 spec rev1–3 full_body；v4.7.1 rev1–3 sections_1_8；rev>=4 用 A 归一化）。验收勾选 A 前若为 `sections_1_8`，改为 `sections_1_8_a_normalized`（front matter 不参与 sign_hash，sign_hash 不变）。
- 签约前机器闸门：`check_spec.py --stage draft`；`--stage spec --print-sign-hash`；`--stage spec --git-check --base <基线>`；`check_roles.py --stage sign`（团队模式 J1）。退出码非零不得请用户签约。
- 团队模式签约前过 J1：`check_roles.py --stage sign` 退出码 0 才可请用户签约；J1 结论附入签约汇报；所有需要用户拍板的选项必须在正文完整列出。
- **签约提醒（原样发送，缺关键词 = FAIL）**：

> 刚才的说明可能造成误解：是否要签约？如果需要签约，请发送“签约”两个字才可以；不发送“签约”两个字，我不会开始编码。只发送这两个字，不要加标点、引号或其他内容。
>
> spec：`docs/specs/<文件>`；请核对条款与决策。继续/同意/可以/确认/通过/按这个做/没问题/OK 均不算签约；“签约，按这个做”也不算。

- 判定：用户消息 `strip()` 后严格等于“签约”才写签约块：`status: signed`、`signed_by`、`signed_at`、`sign_quote: 签约`、`sign_hash`（按 hash_scope）、`confirmed_clauses`、`decisions`；写后跑 `--stage spec` 退出码 0 才编码。主脑不得代写、补记、推断。签约后 spec 正文任何改动 → `sign_hash` 失效，回 draft 重签。
- 团队模式签约时顺带问：“本次是否启用目标管理（目标 + 任务树）？”用户选择写进需求澄清记录；未答/不启用 = 不创建目标。

### 执行中需求变更 / 暂停重签约

1. 主脑先回应用户（当前状态/影响/下一步），不得沉默。
2. spec 立即置 `status: paused`（不先改正文）；审查员向所有活跃子代理发暂停/结束令，主脑只向审查员下达意图。
3. 暂停前把当前 spec 快照到 `tmp/spec-before-<rev>.md`；pause 记录写 `spec_before_revision/hash/snapshot` 且先于任何 spec 编辑落盘；`check_roles.py --stage pause --spec <spec>` 必须为 0。
4. 暂停期间只做只读盘点与 spec 编辑，不写代码、不提交；宿主不能中断时，等在跑子智能体到安全点/自然结束，只停新派发，记录“未能立即停住”。
5. 回 Step 2 改 spec 并重新签约（严格“签约”+新 `sign_hash`），签约后才恢复；受影响闸门（start/J1–J4/测试/安全）重跑。

### 小需求快速通道

同时满足三条时不建 spec 文件，在 PR 描述里写 4 行 mini-spec：只改 1 个文件且不改接口契约；不涉及 DDL/权限/外部输入；影响面为 0。mini-spec 含目标/非目标/契约 C1..Cn/验收 A1..An。越过任一条件（多文件/改接口/动表/动权限/有外部输入）→ 必须走完整 spec。mini-spec Step 1 需求澄清仍做。资格不可自判：三条门槛由客观事实判定；疑义时走完整 spec 或问用户。

**纯文档/流程改动**：只改文档/注释/README/脚本文案，无代码逻辑/接口/数据/权限变化 → 免安全审查与 spec，PR 写“变更摘要 + 影响面（仅文档）”。判断口径：能不能跑到线上产物里。改动涉及流程规则/skill 本身/agent 行为约束时不可免流程，必须走完整 spec。

## Step 3：编码 + 自检

验证：`node --check <file>.js`、`npx tsc --noEmit`、`python -m py_compile <file>.py`、`npm test`/`pytest`、`npm run lint`/`npm run build`；缺的跳过，有静态闸门就一定跑。

### 大文件写保护（>50KB）

触发：整体重写/截断 >50KB 文本文件（文档、日志、配置同规则）。以写前基线为唯一参照，不写死项目行数。流程：`guard_large_write.py prepare <file> --manifest <manifest.json> [--tail-marker "<尾部标记>"]` → 写入 → `check <file> --manifest <manifest.json> [--allow-shrink N]` → 失败立即 `restore`。check 校验 UTF-8、无 U+FFFD、行数 ≥ 基线 − `--allow-shrink`（默认 0）、尾部标记仍在尾部、非空；删除超过 100 行必须显式传 `--allow-shrink N` 并经人工确认。文件/备份/manifest 必须在仓库根内；restore 必须用 prepare 生成的 manifest；退出码非零 = 停，先 restore 再排查。

### 批量文本操作纪律

1. 优先小步 edit（UTF-8）；shell 批量替换只在同构替换 ≥10 处时用。2. shell 批量替换必须显式 UTF-8 读写，禁用依赖系统默认编码的 `Get-Content`/`Set-Content` 组合。3. 写后必验：`git diff` 抽查含中文的行是否完好；乱码/大面积中文行变更 = 立即回滚。4. 改 `.ps1` 后保持 UTF-8 带 BOM。

### UI 视觉自测（坐标断言，不是属性断言）

涉及 CSS/布局/定位/浮层/动画的改动必做；纯后端/逻辑跳过。用 Playwright 量实际渲染坐标（`getBoundingClientRect`），断言写成数值（“距底部 ≤10px”“面板底部 < 选区顶部”“45.2 ±1px”），动画逐帧采样；没有 Playwright 就用 DevTools 手量并把数值记进 PR。样例见 `references/self-check.md`。

### 一致性复查六项

改完逐条过：注释语言 / 变量声明风格 / 全局引用扫描 / 文档清单同步 / 死代码 / 错误提示准确性。判据见 `references/self-check.md`；只在发现问题时汇报。

### 团队模式：编码后先过 J2

裁判员 J2 只做流程/文档/自检证据审计（不审代码、不测试）；代码审查+安全检查由代码安全员做；测试员只做验收测试；J2 PASS 后主脑才进 Step 4。J2 BLOCK → 修正后复审（≤2 轮）；仍不过报用户，不得带病进测试。

## Step 4：测试（两支柱）+ 部署测试系统

测试从契约派生，不从代码派生。代码改了测试跟着改 = 测试失效。

### 入口清单与跳转验收（有 UI 变更时必做）

入口清单来自 Step 2 的实际架构扫描；逐条跳转：打开入口 → 无 404、无未捕获 JS 异常、关键元素可见；结果写测试报告。Step 6 用户按同一清单逐条核对。失败：只写一个入口/未扫描架构/入口 404/未捕获异常/用户先发现 → FAIL。无 UI 变更：spec §2 已写 `入口清单：无 UI 变更` → N/A。

### 支柱 2：新功能达标（契约派生用例）

每条 C 条款至少一个用例，命名带条款号（`test_c1_delete_card_total`）；优先 Python（`requests` 测 HTTP、`pytest`/`unittest` 组织；浏览器路径用 Playwright）；覆盖三组：新功能（条款本身）+ 回归 + 异常路径（只测 spec「失败行为」/「边界与异常」节声明的项）。

### 支柱 1：核心功能没修坏（分级回归）

核心功能清单（一次性）：首次使用/接入新项目时，runbook 没有「核心功能清单」→ 问用户“本项目的核心功能（核心页面/路径）是什么”，记入 `docs/deploy-runbook.md`；已有直接复用。触及核心功能（同页面/同模块/共用接口/共用依赖/共用数据表）→ 核心功能回归：按清单逐条跑（只读）；不触及 → 轻量冒烟：改动路由可打开 + 无未捕获 JS 异常 + 无 5xx。两者均只读（不发消息、不点删除、不写业务数据）、只打测试环境。

扫描清单完备性守则：①新增页面/路由当天必须进回归与扫描清单；②白底/对比度类元素扫描的尺寸阈值须覆盖小元素（≥60×24px 级别）；③断言对构建产物一律归一化匹配（去空白、接受 hex8/rgba 等价、允许 scoped 属性插入）；④断言自身 bug 返工 ≥2 次 = 停下重构断言。已有则复用项目脚本，没有就写最小脚本；输出 `report.json` + `report.md`，退出码非零代表有 FAIL。

### 测试路径真实性核销（定位/浮层/菜单/下拉类改动）

用例操作方式必须与用户真实操作一致：鼠标拖选/点击/键盘输入，而不是 `editor.chain().setTextSelection()`、`element.click()`、直接改 store 等捷径；涉及定位/浮层/菜单/下拉的改动，必须真实鼠标触发（`page.mouse.move/down/up`）；技术限制必须用 API 捷径时，额外补一个“模拟用户鼠标”的对照用例；不一致以用户路径为准。根因教训：API 路径通过 ≠ 用户路径通过。

### 测试报告与 SKIP

报告落 `docs/reviews/<YYYY-MM-DD>-test-report.md`：用例名、命令、退出码、SKIP 数、失败项；核销表 `- 测试报告：` 必须指向它。每个测试文件记录 `path/pre_sha256/post_sha256/run_started_at/run_finished_at`（多文件逐个记录）；`run_started_at` 晚于文件最后修改时间，运行窗口内测试文件不得变更；任一 hash 与当前文件不一致 = 证据作废。SKIP ≠ PASS：测试脚本遇 SKIP 必须退出码 2；退出码 0 + SKIP = 假绿，FAIL。四套测试在冻结快照 <5 分钟；报告记录 `run_started`/`run_finished`；慢测试标 `@slow` 并支持 `--fast`；不写死调用次数。

### 部署测试系统 + 跑回归（仅当项目有测试系统）

通道 A 手动/脚本部署：用项目既有部署脚本；脚本不可用时手动部署：先传临时位置校验，再原子换目录，禁止覆盖式解压；后端先 `cp -p` 备份再覆盖单个文件，只重启改动的服务。通道 B CI/CD 自动发布：推送代码到部署映射对应分支 → 等 workflow 结论 success（`gh run watch`/`gh run list --branch test`）→ 核对线上版本/产物与待测 commit 一致（版本号接口/产物 hash/部署 run 的 commit SHA）→ 才在测试系统跑分级回归。workflow 未完成就跑回归 = 测旧版本，全部“通过”是假通过。workflow 失败/取消/长时间不结束 → 遇阻即停、排查流水线；禁止手动部署绕过。判定：FAIL = 0 才继续；FAIL > 0 先修，把报告失败项贴给用户；WARN 需人工看截图确认。放置与清理：可复用回归用例 → 项目测试目录；一次性脚本 → `tmp/`，Step 9 必须删掉；自动化测试禁止打生产、禁止发真实 AI 消息、禁止写业务数据。

## Step 5：契约核销表（必须 100%）

表 5 列：条款 / 用例名 / 用例文件 / 结果 / 路径真实性。每行必须有用例名、用例文件、结果 ✅、路径真实性；报告里同名 ±2 行内必须有 PASS/通过/✅；不得预填 ✅。有未覆盖条款 = 测试不合格，补用例重跑。表尾写测试报告路径、核销率、分级回归结果。

目标树行（团队模式启用目标时必填）：分母只计 Step 1–5 分组叶子；X = Y 且 `timeline_pull` 中 Step 1–5 无未完成叶子；数值由任务树读取；与 `check_spec.py --stage verify` 是两个并列独立必要条件；`paused` 属未完成，核销前清零；Step 6–9 叶子在 Step 9 收尾汇报给出全树 100%。裁判员 J3/J4 不占本表行；J3 BLOCK 不得核销；裁判员 PASS 不替代机器校验与用户验收。审查报告与失败记录：报告含 `spec_revision`/`spec_hash`/`汇总来源`（列路径且文件存在，C12）；审查员是唯一汇总接口；失败记录落 `docs/reviews/<date>-failure-log.md`（task/subagent/failure_class/attempt/证据/动作/结论）。

机器校验（必做，非零退出 = 核销不合格）：`check_spec.py --stage verify`；`check_roles.py --date <YYYY-MM-DD> --stage verify`；`check_docs.py --root .`；`check_text.py --root .`。`check_spec.py` 四阶段：draft（结构 + 条款/验收编号 + 三问）→ spec（+ 签约块 + 三问已勾）→ verify（+ 5 列核销 + 用例文件/用例名/报告真实性）→ accept（+ 验收块 + A 全勾）。旧 spec（文件名日期 < 2026-11-19）按 legacy 放行；`--strict` 强制新规则。

## Step 6：请用户验收（按清单打勾，不替用户下结论）

验收唯一判定：用户消息 `strip()` 后严格等于“验收”。汇报必含 5 项：①重点变更（改了什么/为什么/影响范围）；②验收标准清单（贴 spec 第 6 节）；③测试步骤与预期；④回滚方式；⑤入口清单逐条跳转结果（无 UI 变更写 N/A）+ 测试报告路径。

团队模式：J4 验收前裁判员必须出具裁判单（PASS / DEVIATION / BLOCK），依据测试员报告、代码安全员代码审查/安全结论与机器校验结果审契约，不执行测试、不审代码；BLOCK 不得请用户验收；汇报附裁判单摘要；裁判员 PASS ≠ 用户验收。用户验收后 Step 7 复用 J4 结论；Step 6 后改代码/spec → 重跑 J4。CI/CD 自动发布项目：通知用户“测试环境已更新”之前，必须确认部署 workflow 结论 success 且线上版本与待验收 commit 一致；不一致 → 先回部署环节修复，不得让用户验收旧版本。

**验收提醒（原样发送，缺关键词 = FAIL）**：

> 刚才的说明可能造成误解：是否需要验收？如果需要验收，请发送“验收”两个字才可以；不发送“验收”两个字，我不会进入 PR。只发送这两个字，不要加标点、引号或其他内容。
>
> 请按 A1–An 验收。没问题/测试通过/提交 PR/发吧/可以/同意 均不算验收；“验收，可以发”也不算。

判定：用户消息 `strip()` 后严格等于“验收”才写验收块：`status: accepted`、`accepted_by`、`accepted_at`、`accept_quote: 验收`、`accept_commit`（当前 HEAD）、`accepted_items`（覆盖全部 A）；spec §6 的 A 项由用户逐条打勾。主脑不得代勾、代写。机器闸门（PR 前必做）：`check_spec.py --stage accept --git-check`；`check_roles.py --date <YYYY-MM-DD> --stage accept`。`accept_commit..HEAD` 只允许 docs/CHANGELOG/spec 变更；含代码 → 撤销验收，回 verify/accept 重跑。`--base` 只用于 Step 2 的 spec 先于实现检查，accept 阶段不用。

团队模式启用目标时：用户严格“验收”后调用 `update_goal` 置 `complete`；未验收不得关闭。同一阻塞连续 3 个自动续轮未解除才置 `blocked` 并写明具体条件——以 `get_goal` 的 `roundsStarted` 为准，不得用汇报次数或重试次数替代；宿主无自动续轮计数时降级为“每轮汇报显式记录同一阻塞出现次数”并注明“轮次口径降级”。遇阻即停：用户发现问题 → 回 Step 2 改 spec → 改代码 → 重跑 4/5 → 重新验收。不带病推进，不顺手加需求。

## Step 7：版本号 + PR

先找项目版本来源：`package.json` / `pyproject.toml` / `VERSION` / `CHANGELOG.md` 顶部 / git tag。有则按 SemVer 递增，无则从 `1.0.0` 起。在项目里明确唯一来源，别让两处版本号打架。本 skill 自身三处一致：`ship-it/SKILL.md` frontmatter、`ship-it/CHANGELOG.md`、根 `CHANGELOG.md`（当前 v4.7.1）。

提交：`git checkout main && git pull` → `git checkout -b feature/<简短描述>` → `git add -A` → `git commit -m "<type>(<scope>): <摘要> [v<版本号>]"` → `git push origin <branch>` → `gh pr create --base main --head <branch>`。

**远端写边界（C2）**：远端写前必须读上传工具的 skill 与脚本实际参数，确认目标分支；PR 仅在验收后创建；合并仅用户。只写通用“上传工具”，不点名其他 skill。`git push` 不可用（公司代理/网络限制）时，改用项目既有的上传工具或可用的上传方式；上传前确认目标分支，不得静默默认 main。

PR 前机器闸门：`check_spec.py --stage accept`、`check_roles.py --stage accept`、`check_docs.py --root .`、`check_text.py --root .` 退出码 0；否则不得创建 PR。团队模式 PR 前复用 J4 裁判单做交付合规复核（版本/CHANGELOG/PR 四块/未代合并/清理计划）；J4 后若有变更 → 重跑 J4。

🔴 **PR 创建即停**：`gh pr create` 是 agent 在本步的最后一个动作。合并按钮永远属于用户——任何时候禁止 agent 执行 `gh pr merge`（无一例外，即使用户说“可以了/发布吧/做吧”也按最窄解释）。创建后把 PR 链接交给用户：“PR 已就绪，请审核后点击合并”。用户点合并 → CI 自动部署（Step 8 由用户的合并动作触发，agent 只负责部署后验证与汇报）。创建 PR ≠ 任务完成：主脑必须停在“等待用户审核/合并”，不得把任务/目标标记完成；用户合并或明确关闭后才进入 Step 8/9；用户要求修改 → 更新同一 PR。

PR 说明四块缺一不可：①版本号 + 变更摘要；②spec 契约（文件、sign_quote/sign_hash、accept_quote/accept_commit、安全增量结论、逐条核销 ✅）；③测试情况（两支柱结果、测试报告路径、测试环境已验证项）；④影响范围/兼容性/回滚方式。

## Step 8：合并后发布正式系统（含回滚预案）

合并前不碰生产（代码、数据库、缓存、进程都算）。没有正式系统则跳过。CI/CD 自动发布项目：合并 PR = 触发生产部署——合并按钮由用户本人点击（agent 任何时候禁止合并 PR）；Step 6 用户验收未通过不得合并。合并后 watch 生产 workflow 结论 success，再执行端到端验证（workflow 绿灯不免除独立验证）。

回滚预案（部署前先填，不填不部署）：当前生产版本（commit/tag/构建号）；上次可用产物（目录/镜像/包路径）；最新数据备份（路径；太旧先做一次）；回滚触发条件（登录失败/核心页面空白/接口 5xx 持续 >1%/数据错乱）；回滚动作（前端换回旧产物目录；后端回退文件并重启对应服务；数据按备份恢复）。CI/CD 变体：当前生产版本 = main 上 commit/最近成功部署 run；上次可用产物 = 上一个成功部署 run（或 release tag）；回滚动作 = `git revert <commit>` 后推回 main 触发自动重部署，或重跑旧 workflow run。禁止直接手改服务器文件回滚（下次自动部署会冲掉、与 git 真源漂移）；确需应急手工介入，事后必须把变更以 commit 形式补回 main 并记录。

发布 + 端到端验证（缺一不可）：查服务/进程状态（`pm2 list`/`docker ps`/`systemctl status`）；源站健康检查（`curl -s http://127.0.0.1:<port>/health`）；对外入口端到端（`curl -s -o /dev/null -w "HTTP %{http_code} - %{time_total}s" https://<域名>/`）；产物 hash 对比（本地 `ls dist/assets/index-*.js` 与远端首页引用一致）；入口资源可达（`curl -s -o /dev/null -w "chunk: %{http_code}\n" "https://<域名>/<入口chunk>"`）。

服务类安全规则：禁止 `pm2 kill` / `pm2 delete all` / `pm2 delete` 不带服务名；只操作具体服务名。操作前先 `pm2 list` 确认当前状态；重启后确认全部 online。前端部署“先清后放”（原子换目录），禁止在旧产物上覆盖。部署前确认目标路径（测试 vs 生产）并确认基线 commit 已合入 main。凭据（`.env` 值、口令、密钥）一律不写进文档、脚本、commit；需要时写“见服务器 `.env`”。耗时不能作为部署失败判据（跨境链路可能 10–60s）；看状态码 + 产物大小/hash 是否与本地一致；有内网/VPN 入口优先用它验证。

## Step 9：清理 + 变更记录

1. 删远程/本地已合并分支：`git push origin --delete <branch>` / `git branch -d <branch>`。2. 垃圾零容忍：删除 `tmp/`、`.tmp/`、`.dsh-project-memory/`、`tests/__pycache__/`、`test/**/*.tmp`、`*.gz`；一次性测试脚本、诊断脚本、临时日志、截图、`.bak` 备份、guard manifest 全部清掉；`git status` 只剩有意提交的文件；确认 `.gitignore` 覆盖到位。pre-commit hook 说明：`.git/hooks/pre-commit` 是本地门禁，不入库、不提交，Step 9 不删除。3. 写变更记录（`CHANGELOG.md` 顶部或项目既有 `deploy-log.md`）：版本、变更内容、测试环境验证、生产部署与验证。4. 同步受影响的文档（端口/表结构/接口/文件清单）。5. 向用户汇报：合并的 PR、版本号、生产状态、清理结果、请强刷提示。

## 版本号规则

| 类型 | 递增 | 示例 |
|---|---|---|
| Bug 修复 | patch | `1.4.2` → `1.4.3` |
| 新功能 | minor | `1.4.3` → `1.5.0` |
| 破坏性更新 | major | `1.5.0` → `2.0.0` |

破坏性变更必须在变更摘要里显式标注 ⚠️。本 skill 版本三处一致（当前 v4.7.1），改一处必须同步另两处。

## 关键原则

1. 不跳步：Step 6 用户验收不能省——自动化通过 ≠ 用户验收通过。2. 每步汇报：做了什么 / 结果 / 下一步。3. 遇阻即停：任何一步失败停下修或等指示，不带病推进。4. spec-first：需求变更先改 spec，再派生代码与测试。5. 默认复用：A/B 优先，选 C 新建必须写成本对比。6. 自测两层性：逻辑正确（条款核销）+ 路径真实（鼠标操作 + 坐标断言）；只过第一层就交付 = 返工。7. 垃圾文件零容忍。8. 凭据纪律。9. 测试只读、只打测试环境。10. 禁止自证：agent 不可自判合规，关键节点（mini-spec 资格 / 纯文档免流程资格 / 核销 ✅ / 能力声明）必须机器可查或用户确认；执行者 ≠ 裁定者 🔒。11. 监督分离：审查员是主脑唯一汇总接口；测试员只做验收测试；代码安全员代码审查+安全检查；裁判员只审契约（不审代码/不测试）；三者只读、只报告，裁判员 PASS 不替代用户验收与机器校验；主脑不得代写审查记录、不得直接给子代理发结束令 🔒。

## 常见坑（通用根因）

| 坑 | 对策 |
|---|---|
| 需求没澄清就做方案 | Step 1 需求澄清（每次做） |
| 只测 happy path | Step 4 异常路径（按 spec 声明） |
| 属性断言当视觉验收 | Step 3 坐标数值断言 |
| API 捷径当用户路径 | Step 4 路径真实性核销 |
| 改完不复查 | Step 3 六项复查 |
| 部署“看起来成功” | 原子换目录 + 明确基线 + 失败即中止 |
| 用耗时判断部署成败 | 看状态码 + 产物 hash/大小 |
| workflow 未完成就跑回归 | 等 success + 版本/产物 hash 核对 |
| 手改服务器救火 | 一切变更走 git 提交触发重部署；应急后以 commit 补回 |
| AI 代合并 PR | 任何时候禁止；PR 创建即停 |
| 跨仓库主体弄反 | Step 1 显式确认基准项目与改动对象 |
| shell 批量替换毁编码 | 显式 UTF-8 + 写后 git diff 抽查中文行 |
| 大文件重写缩水/乱码 | guard prepare/check/restore，按写前基线校验 |
| 审查员越权改代码/直接换模型 | 只可直发 continue/retry_same；换模型/换范围/新派发交主脑 |
| 主脑轮询/静默等待 | 审查员主动巡视；主脑 5 分钟无消息才询问；等待中每 5 分钟向用户发状态 |
| §9 报告前预填 ✅ | 报告后回填；J2 前 C 行“待测”；回填依据写报告时间/哈希 |
| 哈希先报后改 | 最后一次编辑后重新取哈希；消息/报告用同一冻结值 |
| 裁判员替测试员跑测试/审代码 | 裁判员不执行测试、不审代码；J3/J4 只引用测试员报告与代码安全员结论 |
| 审查员只汇总不反问 | 每个报告至少 1 个质疑/反问，拿到回答再总结 |
| 裁判员 PASS 当用户验收 | 裁判员 PASS 只是必要条件；用户“验收”+ 机器校验仍是独立闸门 |
| 审查员开工后补派 | 开工前 `check_roles --stage start` 退出码 0；三份 start artifact 本人写 |
| 改契约未先暂停 | 先 `status: paused` + pause.md（先于 spec 编辑）+ 审查员发暂停令 |
| 执行失败 1 次就主脑接手 | 派发失败 1 次换新；执行失败 3 次换新；主脑不得自做 |
| 文档旧口径/重复/超长 | `check_docs.py` / `check_text.py` 退出码 0 |

## 反偷懒红线（不可自判）

1. 滥用 mini-spec：三条门槛由客观事实判定；任一不符 = 完整 spec；疑义时走完整 spec 或问用户。
2. 滥用纯文档免流程：判断口径由客观事实判定；涉及流程规则/skill/agent 行为约束不可免流程。
3. 跳过需求澄清：Step 1 每次做、分轻重；澄清记录进 spec 第 1 节并展示用户。
4. 测试从代码派生 / 核销表自填 ✅：测试从契约派生；核销 ✅ 必须有用例名+用例文件+报告路径，机器校验退出码 0。
5. 监督角色形同虚设：报告原文必须附入汇报；无 `path:line`/命令+退出码不得 PASS；主脑不得自判核销/验收。

## 反越权红线（不可自判）

1. AI 合并 PR 🔴：任何时候禁止 AI 合并 PR，无一例外；合并只能由用户本人点击；agent 到「PR 已创建」即停。
2. 模糊授权语扩大解释：一律按最窄解释：授权到哪一步就停在哪一步，超出部分停下来问。
3. 部署生产/删数据/删服务/改生产 .env：四类动作执行前必须显式确认；PR 合并触发的 CI 自动部署除外。
4. 跨仓库需求主体弄反：需求涉及 ≥2 个仓库时，Step 1 必须显式确认规范基准与改动对象。
5. 批量文本操作事故：批量替换显式 UTF-8；写后必验；优先小步 edit；`.ps1` 保持 UTF-8 BOM。
6. subagent 派发失效：派发前判定只读/写；派发失败 1 次换新；执行失败 3 次换新；主脑不得自做。
7. 外部服务故障不降级：一轮重试后立即切换手工/替代方案并告知用户。
8. 监督角色越权：三者只读；审查员只可直发 continue/retry_same；裁判员 BLOCK 由主脑整改、PASS 不替代验收/机器校验。

## 项目适配（首次接入 / 换项目）

默认两层：本 skill 管流程；项目 `CLAUDE.md`/`AGENTS.md` 写约定与红线；`docs/deploy-runbook.md` 写环境值、部署/回退/验证命令与回滚卡、核心功能清单；`docs/specs/_TEMPLATE.md` 存模板。不要给项目再造一份流程 skill（两份必然漂移，还会互抢触发）。逐项替换清单见 `references/project-adaptation.md`。

## 作者与商用说明

- 作者：**xianzhe.zhao**（互联网公司 8 年 IT 技术岗，转 AI 产品架构师）。
- **MIT 协议，免费使用/修改/商用**；商用请注明出处「ship-it / xianzhe.zhao」并邮件 **971554652@qq.com** 告知。
